-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Des 2022 pada 16.01
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gis_pariwisata`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_icon`
--

CREATE TABLE `tbl_icon` (
  `id_icon` int(11) NOT NULL,
  `nama_icon` varchar(255) DEFAULT NULL,
  `icon` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tbl_icon`
--

INSERT INTO `tbl_icon` (`id_icon`, `nama_icon`, `icon`) VALUES
(1, 'Marker 1', 'marker1.png'),
(2, 'Marker 2', 'marker2.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_json`
--

CREATE TABLE `tbl_json` (
  `id_json` int(11) NOT NULL,
  `nama_file` varchar(255) DEFAULT NULL,
  `geojson` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tbl_json`
--

INSERT INTO `tbl_json` (`id_json`, `nama_file`, `geojson`) VALUES
(1, 'wisata', 'wisata.geojson');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `no_telpon` varchar(255) DEFAULT NULL,
  `foto` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `email`, `password`, `no_telpon`, `foto`) VALUES
(1, 'admin', 'admin@gmail.com', '1234', '082284039993', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_wisata`
--

CREATE TABLE `tbl_wisata` (
  `id_wisata` int(11) NOT NULL,
  `nama_tempat` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `desa` varchar(255) DEFAULT NULL,
  `kec` varchar(255) DEFAULT NULL,
  `kab` varchar(255) DEFAULT NULL,
  `prov` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL,
  `gambar` text DEFAULT NULL,
  `id_icon` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data untuk tabel `tbl_wisata`
--

INSERT INTO `tbl_wisata` (`id_wisata`, `nama_tempat`, `alamat`, `desa`, `kec`, `kab`, `prov`, `latitude`, `longitude`, `deskripsi`, `gambar`, `id_icon`) VALUES
(1, 'Pantai Senekip Pambang', '1', '1', '1', '1', '1', '1.482666', '102.48407', 'das', 'gambar.jpg', 1),
(2, 'Pantai Prapat Tunggal', '1', '1', '1', '1', '1', '1.5709839', '102.01119', 'asdsad', 'gambar.jpg', 1),
(3, 'Pantai Selat Baru', '1', '1', '1', '1', '1', '1.5631528', '102.24845', 'sadasd', 'gambar.jpg', 1),
(4, 'Pantai Penampar Jangkang', '1', '1', '1', '1', '1', '1.5685245', '102.18719', 'asdas', 'gambar.jpg', 1),
(5, 'Air Mancur Bengkalis', '1', '1', '1', '1', '1', '1.4670137', '102.10948', 'asdasd', 'gambar.jpg', 2),
(6, 'Taman Batu Ampar', '1', '1', '1', '1', '1', '1.4729544', '102.11504', 'asdasd', 'gambar.jpg', 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_icon`
--
ALTER TABLE `tbl_icon`
  ADD PRIMARY KEY (`id_icon`) USING BTREE;

--
-- Indeks untuk tabel `tbl_json`
--
ALTER TABLE `tbl_json`
  ADD PRIMARY KEY (`id_json`) USING BTREE;

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`) USING BTREE;

--
-- Indeks untuk tabel `tbl_wisata`
--
ALTER TABLE `tbl_wisata`
  ADD PRIMARY KEY (`id_wisata`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_icon`
--
ALTER TABLE `tbl_icon`
  MODIFY `id_icon` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_json`
--
ALTER TABLE `tbl_json`
  MODIFY `id_json` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_wisata`
--
ALTER TABLE `tbl_wisata`
  MODIFY `id_wisata` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
