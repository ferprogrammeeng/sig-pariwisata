<div class="row">
	<div class="col-md-12">
		<div class="copyright">
			<p>Copyright © 2022. GIS Pariwisata Kabupaten Bengkalis</p>
		</div>
	</div>
</div>
</div>
</div>
</div>
<!-- END MAIN CONTENT-->
<!-- END PAGE CONTAINER-->
</div>

</div>



<!-- Vendor JS       -->
<script src="<?= base_url() ?>template/vendor/slick/slick.min.js">
</script>
<script src="<?= base_url() ?>template/vendor/wow/wow.min.js"></script>
<script src="<?= base_url() ?>template/vendor/animsition/animsition.min.js"></script>
<script src="<?= base_url() ?>template/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="<?= base_url() ?>template/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="<?= base_url() ?>template/vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="<?= base_url() ?>templaate/vendor/circle-progress/circle-progress.min.js"></script>
<script src="<?= base_url() ?>template/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?= base_url() ?>template/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="<?= base_url() ?>template/vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="<?= base_url() ?>template/js/main.js"></script>
<script>
	window.setTimeout(function() {
		$(".alert").fadeTo(500, 0).slideUp(500, function() {
			$(this).remove();
		});
	}, 3000);
	initSample();
</script>
</body>

</html>
<!-- end document-->
